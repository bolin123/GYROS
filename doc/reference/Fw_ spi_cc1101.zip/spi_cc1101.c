
#include "spi_cc1101.h"


#define		INT8U		unsigned char
/* Private define ------------------------------------------------------------*/
#define WRITE      0x82  /* Write to Memory instruction */
#define READ       0xD3  /* Read from Memory instruction */
#define RDSR       0xD7  /* Read Status Register instruction  */
#define RDID       0x9F  /* Read identification */
#define PE         0x81  /* Page Erase instruction */
#define BE1        0xC7  /* Bulk Erase instruction */
#define BE2        0x94  /* Bulk Erase instruction */
#define BE3        0x80  /* Bulk Erase instruction */
#define BE4        0x9A  /* Bulk Erase instruction */

#define BUSY_Flag  0x01 /* Ready/busy status flag */

#define Dummy_Byte 0xff

/*******************************************************************************/
#define 	WRITE_BURST     	0x40						//????
#define 	READ_SINGLE     	0x80						//?
#define 	READ_BURST      	0xC0						//???
#define 	BYTES_IN_RXFIFO     0x7F  						//???????????
#define 	CRC_OK              0x80 						//CRC???????
// CC1100 STROBE, CONTROL AND STATUS REGSITER

#define TOTX_TIME         2  //ms
#define TORX_TIME         2  //ms
#define MAX_TX_TIME       20    //ms
#define MAX_RF_WAIT       20    //ms 

uint8_t RF_READ_FIG = 0;
uint8_t g_RFRecv = 0;

#ifndef  paTableLen
u8 PaTabel[] = {0x12,0x0e,0x1d,0x34,0x60,0x84,0xc8,0xc0,0xc0};
u8 paTableLen = 4;  
#endif

uint8_t g_rx_buf[20];

void SPI_CC1101_Init(void)
{
	SPI_InitTypeDef  SPI_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOA , ENABLE);
	
	/* Configure SPI2 pins: SCK, MISO and MOSI */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_SCLK | GPIO_Pin_SO | GPIO_Pin_SI;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	/* Configure I/O for cc1101 Chip select */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_CS;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIO_CS, &GPIO_InitStructure);
	
	/* Configure I/O for PB8,PB9  */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_GD0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	/* Deselect the FLASH: Chip Select high */
	
	/* Enable SPI1 and GPIO clocks */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	
	/* SPI2 configuration */
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//SPI_Direction_2Lines_RxOnly;//SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);
	
	/* Enable SPI2  */
	SPI_Cmd(SPI1, ENABLE);
}

void NVIC_Configuration()
{
	NVIC_InitTypeDef   NVIC_InitStructure;
	
    /* Enable and set EXTI3 Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void GPIO_GDO0_ENABLE(void)
{
		EXTI_InitTypeDef EXTI_InitStructure;
    /* Connect GDO0 EXTI Line to Button GPIO Pin */
    GPIO_EXTILineConfig(GPIO_GDO0_EXTI_PORT_SOURCE, GPIO_GDO0_EXTI_PIN_SOURCE);  

    /* Configure GDO0 EXTI line */
    EXTI_InitStructure.EXTI_Line = GPIO_GDO0_EXTI_LINE;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

void GPIO_GDO0_DISABLE(void)
{
	  EXTI_InitTypeDef EXTI_InitStructure;
   		//�жϳ�ʼ��
    /* Connect GDO0 EXTI Line to Button GPIO Pin */
//		SYSCFG_EXTILineConfig(RF_IQR_PORT_SOURCE, RF_IQR_SOURCE);
    /* Configure GDO0 EXTI line */			
		EXTI_InitStructure.EXTI_Line = GPIO_GDO0_EXTI_LINE;
		EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�������ж�
		EXTI_InitStructure.EXTI_LineCmd = DISABLE;
		EXTI_Init(&EXTI_InitStructure); 
}

u8 SPI_FLASH_ReadByte(void)
{
  return (SPI_FLASH_SendByte(Dummy_Byte));
}

u8 SPI_FLASH_SendByte(u8 byte)
{
  /* Loop while DR register in not emplty */
//  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
	hal_wait_ms_cond(MAX_RF_WAIT, !SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
  /* Send byte through the SPI2 peripheral */
  SPI_I2S_SendData(SPI1, byte);

  /* Wait to receive a byte */
//  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET);
	hal_wait_ms_cond(MAX_RF_WAIT, !SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
  /* Return the byte read from the SPI bus */
  return SPI_I2S_ReceiveData(SPI1);
}

/**********************************CC1101********************/

void Delay(u32 nCount)
{
  int i,j;
  for(j=0;j<nCount;j++)
  {
     for(i=0;i<10;i++);
  }
}


INT8U SPI_CC1101_ReadID(void)
{
	 INT8U id;
	 SPI_FLASH_CS_LOW();
	 	 
	 SPI_FLASH_SendByte(CCxxx0_SFSTXON);
	 id = SPI_FLASH_SendByte(0xff);
	 SPI_FLASH_CS_HIGH();

	 return id;
}

void CC1101_POWER_RESET(void)
{
  SPI_FLASH_CS_HIGH();
  Delay(30);
  SPI_FLASH_CS_LOW();
  Delay(30);
  SPI_FLASH_CS_HIGH();
  Delay(45);
  SPI_FLASH_CS_LOW();
//  while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );//waite SO =0
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
  SPI_FLASH_SendByte(CCxxx0_SRES);
//  while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );//waite SO =0 again 
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
  SPI_FLASH_CS_HIGH(); 
}


void halSpiWriteReg(INT8U addr, INT8U value) 
{
    SPI_FLASH_CS_LOW();
//    while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
    SPI_FLASH_SendByte(addr);		//???
    SPI_FLASH_SendByte(value);		//????
    SPI_FLASH_CS_HIGH(); 
}


void halSpiWriteBurstReg(INT8U addr, INT8U *buffer, INT8U count) 
{
    INT8U i, temp;
	temp = addr | WRITE_BURST;
    SPI_FLASH_CS_LOW();
  //  while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO));
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
    SPI_FLASH_SendByte(temp);
    for (i = 0; i < count; i++)
 	{
        SPI_FLASH_SendByte(buffer[i]);
    }
    SPI_FLASH_CS_HIGH(); 
}

void halSpiStrobe(INT8U strobe) 
{
    SPI_FLASH_CS_LOW();
//    while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
    SPI_FLASH_SendByte(strobe);		//????
    SPI_FLASH_CS_HIGH();
}


void halRfSendPacket(INT8U *txBuffer, INT8U size) 
{

		halSpiStrobe(CCxxx0_SFTX);

    halSpiWriteBurstReg(CCxxx0_TXFIFO, txBuffer, size);	//????????

    halSpiStrobe(CCxxx0_STX);		//??????????	

    // Wait for GDO0 to be set -> sync transmitted
//    while (!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) );//while (!GDO0);
		hal_wait_ms_cond(MAX_RF_WAIT, (GPIO_ReadInputDataBit(GPIOB,GPIO_GDO0)));
    // Wait for GDO0 to be cleared -> end of packet
    while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) );// while (GDO0);
		hal_wait_ms_cond(MAX_RF_WAIT, (!GPIO_ReadInputDataBit(GPIOB,GPIO_GDO0)));
//	halSpiStrobe(CCxxx0_SFTX);
}


void halRfSendData(INT8U txData)
{
	halSpiStrobe(CCxxx0_SFTX);
    halSpiWriteReg(CCxxx0_TXFIFO, txData);	//????????

    halSpiStrobe(CCxxx0_STX);		//??????????	

    // Wait for GDO0 to be set -> sync transmitted
  //  while (!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) );//while (!GDO0);
	hal_wait_ms_cond(MAX_RF_WAIT, (GPIO_ReadInputDataBit(GPIOB,GPIO_GDO0)));
    // Wait for GDO0 to be cleared -> end of packet
 //   while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) );// while (GDO0);
	hal_wait_ms_cond(MAX_RF_WAIT, (!GPIO_ReadInputDataBit(GPIOB,GPIO_GDO0)));
//	halSpiStrobe(CCxxx0_SFTX);
}


INT8U halSpiReadReg(INT8U addr) 
{
	INT8U temp, value;
    temp = addr|READ_SINGLE;//??????
	SPI_FLASH_CS_LOW();
	//while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );//MISO
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
	SPI_FLASH_SendByte(temp);
	value = SPI_FLASH_SendByte(0);
	 SPI_FLASH_CS_HIGH();
	return value;
}


void halSpiReadBurstReg(INT8U addr, INT8U *buffer, INT8U count) 
{
    INT8U i,temp;
		temp = addr | READ_BURST;		//????????????????
    SPI_FLASH_CS_LOW();
  //   while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO));
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
		SPI_FLASH_SendByte(temp);   
    for (i = 0; i < count; i++) 
		{
        buffer[i] = SPI_FLASH_SendByte(0);
    }
    SPI_FLASH_CS_HIGH();
}


INT8U halSpiReadStatus(INT8U addr) 
{
    INT8U value,temp;
	temp = addr | READ_BURST;		//????????????????????
    SPI_FLASH_CS_LOW();
 //   while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_SO) );
	hal_wait_ms_cond(MAX_RF_WAIT, !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_SO));
    SPI_FLASH_SendByte(temp);
	value = SPI_FLASH_SendByte(0);
	SPI_FLASH_CS_HIGH();
	return value;
}

INT8U halRfReceivePacket(INT8U *rxBuffer, INT8U *length) 
{
    INT8U status[2];
    INT8U packetLength;
	 
    if ((halSpiReadStatus(CCxxx0_RXBYTES) & BYTES_IN_RXFIFO)) //?????????0
	{
	    packetLength = halSpiReadReg(CCxxx0_RXFIFO);//???????,??????????
		rxBuffer[0] = packetLength;//������һ���ֽڣ����ֽ�Ϊ��֡���ݳ���
        if(packetLength <= *length) 		//?????????????????????????
		{
            halSpiReadBurstReg(CCxxx0_RXFIFO, rxBuffer+1, packetLength+2); //??????????
            *length = packetLength;				//??????????????????
        
            // Read the 2 appended status bytes (status[0] = RSSI, status[1] = LQI)
      //      halSpiReadBurstReg(CCxxx0_RXFIFO, status, 2); 	//??CRC???
						halSpiStrobe(CCxxx0_SFRX);		//???????
            return 1;//(status[1] & CRC_OK);			//????????????
        }
		 else 
			{
            *length = packetLength;
            halSpiStrobe(CCxxx0_SFRX);		//???????
            return 0;
        }
    } 
	else
 	return 0;
}


void halRfWriteRfSettings(void) 
{

	halSpiWriteReg(CCxxx0_IOCFG0,		0x06);  //GDO0 Output Pin Configuration
	halSpiWriteReg(CCxxx0_PKTLEN,		0xFF);  //Packet Length
	halSpiWriteReg(CCxxx0_PKTCTRL0,	0x05);  //Packet Automation Control
	halSpiWriteReg(CCxxx0_ADDR,			0x00);    //Device Address
	halSpiWriteReg(CCxxx0_CHANNR,		0x0A);  //Channel Number
	halSpiWriteReg(CCxxx0_FSCTRL1,	0x06); //Frequency Synthesizer Control
	halSpiWriteReg(CCxxx0_FREQ2,		0x10);   //Frequency Control Word, High Byte
	halSpiWriteReg(CCxxx0_FREQ1,		0xB1);   //Frequency Control Word, Middle Byte
	halSpiWriteReg(CCxxx0_FREQ0,		0x3B);   //Frequency Control Word, Low Byte
	halSpiWriteReg(CCxxx0_MDMCFG4,	0x25); //Modem Configuration
	halSpiWriteReg(CCxxx0_MDMCFG3,	0x83); //Modem Configuration
	halSpiWriteReg(CCxxx0_MDMCFG2,	0x13); //Modem Configuration
	halSpiWriteReg(CCxxx0_DEVIATN,	0x60); //Modem Deviation Setting
	halSpiWriteReg(CCxxx0_MCSM0,		0x18);   //Main Radio Control State Machine Configuration
    halSpiWriteReg(CCxxx0_MCSM1,		0x3f);
	halSpiWriteReg(CCxxx0_FOCCFG,		0x16);  //Frequency Offset Compensation Configuration
	halSpiWriteReg(CCxxx0_WORCTRL,	0xFB); //Wake On Radio Control
	halSpiWriteReg(CCxxx0_FSCAL3,		0xE9);  //Frequency Synthesizer Calibration
	halSpiWriteReg(CCxxx0_FSCAL2,		0x2A);  //Frequency Synthesizer Calibration
	halSpiWriteReg(CCxxx0_FSCAL1,		0x00);  //Frequency Synthesizer Calibration
	halSpiWriteReg(CCxxx0_FSCAL0,		0x1F);  //Frequency Synthesizer Calibration
	halSpiWriteReg(CCxxx0_TEST0,		0x09);   //Various Test Settings
	halSpiWriteReg(CCxxx0_PATABLE,	0xc0);   //Various Test Settings
	
	halSpiStrobe(CCxxx0_SIDLE);    //CCxxx0_SIDLE	 0x36 //����״̬
	halSpiStrobe(CCxxx0_SCAL);    //CCxxx0_SIDLE	 0x36 //����״̬

}

uint16_t CC1101_WOR_Init(uint32_t Time)
{
    u32 EVENT0=0;
    u16 WOR_RES=1;
    u16 WOR_rest=1; //2^(5*WOR_RES)
        
    if(Time<15 | Time>61946643) return 0;
    if(Time<1890) WOR_RES=0;
    else if(Time<60494) WOR_RES=1;
    else if(Time<1935832) WOR_RES=2;
    else if(Time<61946643) WOR_RES=3;

    WOR_rest <<= 5*WOR_RES;
    EVENT0 = 26000000/1000;
    if(EVENT0>Time)
    {
    EVENT0 = EVENT0*Time;
    EVENT0 = EVENT0/(750*WOR_rest);
    }
    else
    {
    EVENT0 = (Time/(750*WOR_rest))*EVENT0;
    }
    halSpiStrobe(CCxxx0_SIDLE);
 

    halSpiWriteReg(CCxxx0_IOCFG2, 0x06);
    halSpiStrobe(CCxxx0_SFRX);
    halSpiStrobe(CCxxx0_SWORRST);
    halSpiStrobe(CCxxx0_SWOR);
    return 1;
}

/**********************************************************
** ��������: CC1101_WOR_Send
** ��������: CC1101��������ͬһ�����ݰ�������WOR�豸
** �䡡  ��: *txBuffer:��������size:���ݳ��ȣ�cnt:���ʹ���
** ��    ��: 
** ȫ�ֱ���: 
** ����ģ��: 
** ˵    ���� 
** ע    �⣺
***********************************************************/ 
void CC1101_WOR_Send(uint8_t *txBuffer, uint8_t size, uint16_t cnt)
{
	uint16_t i;
	
	halSpiStrobe(CCxxx0_SIDLE);
	halSpiStrobe(CCxxx0_SFSTXON);	
	for(i=0; i<cnt; i++)
	{		
		halSpiWriteReg(CCxxx0_TXFIFO, size);
		halSpiWriteBurstReg(CCxxx0_TXFIFO, txBuffer, size);	//д��Ҫ���͵�����
		halSpiStrobe(CCxxx0_STX);		//���뷢��ģʽ��������	

    hal_wait_ms_cond(MAX_RF_WAIT, (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) ));

		hal_wait_ms_cond(MAX_RF_WAIT, (!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_GD0) ));
	}
}

void RF_CC1101_SLEEP(void)
{	
	halSpiStrobe(CCxxx0_SPWD); 
	halSpiStrobe(CCxxx0_SWOR); 		//����WOR
}

void RFInit(void)
{
	NVIC_Configuration();
	SPI_CC1101_Init();
	CC1101_POWER_RESET();
	halRfWriteRfSettings();
	
	GPIO_GDO0_ENABLE();
	halSpiStrobe(CCxxx0_SRX);
}

SysTime_t RFPollTime;
void RFPoll(void)
{ 
	u8 i;
	if(SysTimeHasPast(RFPollTime,1000))
	{
		RFPollTime = SysTime();
	}
	if(g_RFRecv)
	{
		g_RFRecv = 0;
		SysLog("RFRecv is ");
		for(i=0;i<g_rx_buf[0];i++)
		{
			SysPrintf("%d ",g_rx_buf[i]);
		}
	}
}


/*************************************************************/
